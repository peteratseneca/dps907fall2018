﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace A5Owner.Models
{

    // Add your app's domain or design model classes below
    // Delete the example "Gizmo" class...

    public class Gizmo
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}